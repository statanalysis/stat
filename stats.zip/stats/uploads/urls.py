from django.conf.urls import url
from django.contrib import admin
from django.conf import settings
from django.conf.urls.static import static

from uploads.core import views


urlpatterns = [
    url('upload', views.simple_upload, name='simple_upload'),
    url('deletefile', views.deletefile, name='deletefile'),
    url('methodone', views.doone, name='methodone'),
    url(r'^admin/', admin.site.urls),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
