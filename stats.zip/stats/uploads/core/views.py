from django.shortcuts import render, redirect
from django.conf import settings
from django.core.files.storage import FileSystemStorage
from django.template import loader
from django.http import *
import os
import win32com.client
import win32com.client
import pandas as pd
import glob
import shutil
import plotly.offline as plotly
import numpy
import numpy as np
import pandas as pd
import pythoncom
from plotly.graph_objs import Scatter, Figure, Layout

fileno=0
def stat(filepath):
    timeseries = ""
    details_list = []
    '''creating dataframe'''
    d = pd.read_excel(filepath, "Sheet1") 
    headers=list(d)

    time=d[headers[0]].values.tolist()
    timeseries = "Timeseries:" + str(time[0]) + "to" + str(time[-1])
    values=d[headers[1]].values.tolist()
    mean = np.mean(values)
    maximum = max(values)
    stddev = np.std(values)
    avgzcross =0
    significant=0
    percent37=0
    percent57=0
    percent90=0
    percent95=0
    details_list.append(mean)
    details_list.append(stddev)
    details_list.append(maximum)
    details_list.append(avgzcross)
    details_list.append(significant)
    details_list.append(percent37)
    details_list.append(percent57)
    details_list.append(percent90)
    details_list.append(percent95)
    return timeseries,details_list

    pass




def simple_upload(request):
    global fileno
    try:
        if request.FILES["myfile"]:
            pass
    except :
        path = os.getcwd()
        path = path + "\\media\\"
        label = os.listdir(path + '\\executed')
        context = {"label":label}
        template = loader.get_template('core/simple_upload.html')
        return HttpResponse(template.render(context, request))
        
    pythoncom.CoInitialize()
    
    if request.method == 'POST' and request.FILES["myfile"]:
        ''' deleting folder media '''
        path = os.getcwd()
        path = path + "\\media\\"
        xlsxfiles=os.listdir(path)
        for file in xlsxfiles:
             if file.endswith(".xlsx"):
                 os.remove(os.path.join(path, file))

        

        ''' for saving the file one by one'''
        for count, x in enumerate(request.FILES.getlist("myfile")):
            fs = FileSystemStorage()
            filename = fs.save(x.name, x)
            uploaded_file_url = fs.url(filename)
        
        '''preprocess starts here '''

        path = os.getcwd()
        path = path + "\\media\\"
        '''terminate Excel running '''
        os.system('taskkill /f /im Excel.exe')


        if not os.path.exists(path + "executed"):
          os.makedirs(path + "executed")

        files = glob.iglob(os.path.join(path, "*.xlsx"))
        for file in files:
          if '~' not in file:
            
            filename = file
            print(filename)
            sheetname = 'Sheet1'
            xl = win32com.client.DispatchEx('Excel.Application')
            wb = xl.Workbooks.Open(Filename=filename)
            ws = wb.Sheets(sheetname)
            '''remove empty row from excel files'''
            begrow = 1
            endrow = ws.UsedRange.Rows.Count

            count = -2
            for row in range(begrow, endrow + 1):

                 if "float" in str(type(ws.Range('A{}'.format(row)).Value)):
                     break
                 else:
                     count = count + 1

            while count >= 0:
                ws.Range('A{}'.format(begrow)).EntireRow.Delete(Shift=-4162)
                count = count - 1

            filepathsplit = file.split('\\')
            newfilename = ""
            for f in filepathsplit:
              if '.xlsx' in f:
                newfilename = newfilename + f

            wb.SaveAs(path + 'executed\\' + str(fileno) + newfilename)
            fileno=fileno+1
            wb.Close()
            xl.Quit()
            os.system('taskkill /f /im Excel.exe')
            os.system('taskkill /f /im Excel.exe')
        '''preprocess ends here'''

        '''plotting 
        d = pd.read_excel(path + 'executed\\' + "Data Set.xlsx", "Sheet1")
        from plotly.graph_objs import Scatter, Figure, Layout
        plotly.plot([Scatter(x=d['Time,s'], y=d[' Tension, kN'])])
        print(np.mean(d['Time,s']))'''

    label = os.listdir(path + '\\executed')
    print(label)
    context = {"label":label}
    template = loader.get_template('core/simple_upload.html')
    return HttpResponse(template.render(context, request))
    

def doone():
    path = os.getcwd()
    path = path + "\\media"
    label = os.listdir(path + '\\executed')

    for l in label:
        t,details=stat(path + '\\executed\\'+l)
        keyvalue.append(details)
        time.append(t)
    
    
    dtime=zip(keyvalue,time)
    context = {"dtime":dtime}
    template = loader.get_template('core/index.html')
    return HttpResponse(template.render(context, request))

def deletefile(request):
    path = os.getcwd()
    path = path + "\\media\\executed"
    
    try:
        filename=request.GET.get("name", "")
        os.remove(os.path.join(path, filename))
    except :
        pass
    

    label = os.listdir(path)
    print(label)
    context = {"label":label}
    template = loader.get_template('core/simple_upload.html')
    return HttpResponse(template.render(context, request))