from __future__ import unicode_literals

from django.db import models
from datetime import datetime, timedelta, date

class tagname(models.Model):
    tagname = models.CharField(max_length=250)
    method = models.CharField(max_length=250,default='')
    datetime = models.DateTimeField(default=datetime.now())

class methodone(models.Model):
    tagname = models.CharField(max_length=250)
    datetime = models.DateTimeField(default=datetime.now())
    timeseries=models.CharField(max_length=250,default="")
    mean=models.DecimalField(max_digits=40, decimal_places=20)
    stddev=models.DecimalField(max_digits=40, decimal_places=20)
    maximum=models.DecimalField(max_digits=40, decimal_places=20)
    zerocross=models.DecimalField(max_digits=40, decimal_places=20)
    significant=models.DecimalField(max_digits=40, decimal_places=20)
    threeseven=models.DecimalField(max_digits=40, decimal_places=20)
    fiveseven=models.DecimalField(max_digits=40, decimal_places=20)
    ninezero=models.DecimalField(max_digits=40, decimal_places=20)
    ninefive=models.DecimalField(max_digits=40, decimal_places=20)

class newmethodone(models.Model):
    tagname = models.CharField(max_length=250)
    datetime = models.DateTimeField(default=datetime.now())
    timeseries=models.CharField(max_length=250,default="")
    mean=models.DecimalField(max_digits=40, decimal_places=20)
    stddev=models.DecimalField(max_digits=40, decimal_places=20)
    maximum=models.DecimalField(max_digits=40, decimal_places=20)
    zerocross=models.DecimalField(max_digits=40, decimal_places=20)
    significant=models.DecimalField(max_digits=40, decimal_places=20)
    threeseven=models.DecimalField(max_digits=40, decimal_places=20)
    fiveseven=models.DecimalField(max_digits=40, decimal_places=20)
    ninezero=models.DecimalField(max_digits=40, decimal_places=20)
    ninefive=models.DecimalField(max_digits=40, decimal_places=20)

class avgmethodone(models.Model):
    tagname = models.CharField(max_length=250)
    datetime = models.DateTimeField(default=datetime.now())
    mean=models.DecimalField(max_digits=40, decimal_places=20)
    stddev=models.DecimalField(max_digits=40, decimal_places=20)
    maximum=models.DecimalField(max_digits=40, decimal_places=20)
    zerocross=models.DecimalField(max_digits=40, decimal_places=20)
    significant=models.DecimalField(max_digits=40, decimal_places=20)
    threeseven=models.DecimalField(max_digits=40, decimal_places=20)
    fiveseven=models.DecimalField(max_digits=40, decimal_places=20)
    ninezero=models.DecimalField(max_digits=40, decimal_places=20)
    ninefive=models.DecimalField(max_digits=40, decimal_places=20)
    


