from django.contrib import admin
from .models import *
# Register your models here.
admin.site.register(tagname)
admin.site.register(avgmethodone)
admin.site.register(methodone)
admin.site.register(newmethodone)

